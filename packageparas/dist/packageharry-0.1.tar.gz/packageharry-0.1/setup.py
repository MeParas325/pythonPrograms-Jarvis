from setuptools import setup
setup(name = "packageharry",
version = "0.1",
description = "This is Paras package",
long_description = "This is long description",
author = "Paras",
packages = ['packageparas'],
install_requires = [])
