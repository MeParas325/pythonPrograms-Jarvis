def func(number):
    print("This is a function")
    return number